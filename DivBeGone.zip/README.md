# DivBeGone
A chrome extension that removes divs containing the specified search terms. 
